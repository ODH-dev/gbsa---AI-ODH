# -*- coding: utf-8 -*-
"""발주요청서 일꾼 — ERP 발주 참고 자료 저장
ERP_발주자료_가져오기.js 결과를 자료/가져오기원본/ERP_발주자료_YYMMDD_HHMM.txt 로 그대로 저장한 뒤:
  python3 도구/ERP_발주자료_저장.py 자료/가져오기원본/ERP_발주자료_YYMMDD_HHMM.txt
→ 지문 검사 → 자료/ERP_발주참고_YYMMDD.xlsx (같은 내용이면 그대로, 다르면 _2) + 자료/ERP_가져오기_기록.md 한 줄
"""
import sys, os, re, datetime as dt
from openpyxl import Workbook, load_workbook
KST = dt.timezone(dt.timedelta(hours=9))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = sys.argv[1]
text = open(src, encoding="utf-8").read().rstrip("\n")
l1, l2, body = text.split("\n", 2)
m1 = re.search(r"ERP v(\d+) · 발주 참고 자료 · 받은 시각 (\S+)", l1); m2 = re.search(r"지문 (\d+) · 줄 (\d+)", l2)
if not (m1 and m2): sys.exit("맨 위 두 줄(# ERP v… / # 지문 …)이 없습니다. 가져오기 결과를 그대로 저장해 주세요.")
h = 0
for ch in body: h = (h * 31 + ord(ch)) & 0xFFFFFFFF
if h != int(m2.group(1)) or len(body.split("\n")) != int(m2.group(2)):
    sys.exit(f"지문이 다릅니다(ERP {m2.group(1)} / 저장본 {h}). 저장하지 않았습니다. 다시 가져오세요.")
NEED = ["품목", "거래처", "매입 발주", "구매 요청", "자동 초안", "결재 계정"]
parts = {}
for blk in body.split("## ")[1:]:
    ls = blk.split("\n"); parts[ls[0].strip()] = [l.split("\t") for l in ls[1:] if l != ""]
miss = [n for n in NEED if n not in parts]
if miss: sys.exit(f"빠진 부분: {miss}")
NUMS = {"매입 발주": (3, 4), "구매 요청": (5, 6), "자동 초안": (2,)}
def num(v):
    try: return int(str(v).replace(",", ""))
    except ValueError: return v
data = {n: [parts[n][0]] + [[num(v) if j in NUMS.get(n, ()) else v for j, v in enumerate(r)] for r in parts[n][1:]] for n in NEED}
ymd = dt.datetime.now(KST).strftime("%y%m%d")
path = os.path.join(ROOT, "자료", f"ERP_발주참고_{ymd}.xlsx"); state = "새로 저장"
def same(p):
    wb = load_workbook(p); return all(n in wb.sheetnames and [["" if v is None else v for v in r] for r in wb[n].iter_rows(values_only=True)] == data[n] for n in NEED)
if os.path.exists(path):
    if same(path): state = "같은 내용이 이미 있어 그대로 둠"
    else:
        n = 2
        while os.path.exists(path.replace(".xlsx", f"_{n}.xlsx")): n += 1
        path = path.replace(".xlsx", f"_{n}.xlsx")
if state == "새로 저장":
    wb = Workbook(); wb.remove(wb.active)
    for n in NEED:
        ws = wb.create_sheet(n)
        for r in data[n]: ws.append(r)
        ws.freeze_panes = "A2"
    ws = wb.create_sheet("출처"); ws.append(["ERP 버전", m1.group(1)]); ws.append(["받은 시각", m1.group(2)]); ws.append(["원본", os.path.relpath(src, ROOT)]); ws.append(["지문", m2.group(1)])
    wb.save(path)
cnt = " · ".join(f"{n} {len(data[n])-1}" for n in NEED)
line = f"- {dt.datetime.now(KST):%Y-%m-%d %H:%M} · ERP v{m1.group(1)} · 발주 참고 자료 · {cnt} · 지문 일치 · {os.path.basename(path)}({state}) · 원본 {os.path.relpath(src, ROOT)}"
with open(os.path.join(ROOT, "자료", "ERP_가져오기_기록.md"), "a", encoding="utf-8") as f: f.write(line + "\n")
print(line)
