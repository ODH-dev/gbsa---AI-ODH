// 발주요청서 일꾼 — D SMART ERP 발주 참고 자료 가져오기 (ERP 화면을 연 상태로 브라우저에서 실행)
// 읽기만 한다: 조회(GET)만 하고 ERP 자료는 바꾸지 않음. 파일로 내려받지 않고 글자 + 지문으로 돌려줌
// 가져오는 것: 품목(코드·이름·단위) · 거래처 · 매입 발주 기록 · 구매 요청(전자결재) · ERP 부족 재고 자동 초안 · 결재 가능 계정(이름·메일 제외)
await (async () => {
  const get = async u => { const r = await fetch(u, { cache: 'no-store' }); const j = await r.json(); if (!r.ok || j.error) throw Error(u + ' : ' + (j.error || r.status)); return j; };
  const sh = await get('/api/shared'), tm = await get('/api/team');
  let ops = { restocks: [] }; try { ops = await get('/api/operations'); } catch (e) { ops = { restocks: null, err: String(e.message) }; }
  const d = sh.data || {}, pm = d.portfolioModules || {};
  const clean = v => String(v ?? '').replace(/[\t\n\r]/g, ' ').trim();
  const sec = (n, h, rows) => '## ' + n + '\n' + [h, ...rows].map(r => r.map(clean).join('\t')).join('\n');
  const parts = [
    sec('품목', ['품목코드', '품목명', '단위'], (d.products || []).map(p => [p.code, p.name, p.unit])),
    sec('거래처', ['거래처코드', '거래처명', '거래구분', '취급품목', '상태'], (pm.partners || []).map(p => [p.code, p.name, p.type, p.items, p.status])),
    sec('매입 발주', ['발주번호', '매입처', '품목코드', '발주수량', '단가', '발주일', '상태'], (pm.purchase || []).map(p => [p.number, p.partner, p.code, p.quantity, p.price, p.date, p.status])),
    sec('구매 요청', ['요청ID', '요청번호', '제목', '종류', '품목코드', '수량', '단가', '상태', '제출시각'], (tm.requests || []).map(r => [r.id, r.request_key, r.title, r.kind, r.product_code, r.quantity, r.unit_price, r.status, r.submitted_at])),
    sec('자동 초안', ['초안ID', '품목코드', '수량', '상태', '결재상태', '요청ID'], ops.restocks ? ops.restocks.map(r => [r.id, r.product_code, r.quantity, r.status, r.approval_status, r.request_id]) : [['조회 안 됨', ops.err || '', '', '', '', '']]),
    sec('결재 계정', ['계정ID', '역할', '부서', '로그인 연결', '본인'], (tm.members || []).filter(m => m.active !== 0).map(m => [m.id, m.role, m.department, (m.connected ?? !!m.user_id) ? '예' : '아니오', m.id === tm.me?.id ? '본인' : ''])),
  ];
  const body = parts.join('\n');
  let h = 0; for (const ch of body) h = (Math.imul(h, 31) + ch.codePointAt(0)) >>> 0;
  return `# ERP v${sh.revision} · 발주 참고 자료 · 받은 시각 ${new Date().toISOString()}\n# 지문 ${h} · 줄 ${body.split('\n').length}\n` + body;
})();
