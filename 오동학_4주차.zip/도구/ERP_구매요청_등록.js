// 발주요청서 일꾼 — ERP 구매 요청 등록 (사용자가 'ERP에 등록해' 라고 확인한 뒤에만 실행)
// 맨 아래 [] 안에 결과/ERP등록예정_….json 의 "등록" 목록을 그대로 붙여 넣는다.
// 하는 일: ① 같은 요청번호가 이미 ERP에 있는지 먼저 조회 → 있으면 새로 만들지 않음
//         ② 없는 것만 전자결재 '구매 요청'으로 제출(같은 요청번호 재시도는 ERP가 중복을 막음) ③ 다시 조회해 요청ID·상태를 확인
// 승인·반려·발주 확정·재고 변경은 하지 않는다.
await (async (LIST) => {
  const team = async () => { const r = await fetch('/api/team', { cache: 'no-store' }); const j = await r.json(); if (!r.ok || j.error) throw Error(j.error || r.status); return j; };
  const before = await team(), byKey = k => (before.requests || []).find(r => r.request_key === k);
  const res = {};
  for (const p of LIST) {
    if (byKey(p.request_key)) { res[p.request_key] = ['이미 있음', '']; continue; }
    try {
      const r = await fetch('/api/team', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'create', ...p }) });
      const j = await r.json().catch(() => ({}));
      res[p.request_key] = r.ok && j.ok ? ['제출', ''] : ['실패', String(j.error || r.status)];
    } catch (e) { res[p.request_key] = ['응답 없음', String(e.message)]; }
  }
  const after = await team();
  const body = '요청번호\t품목코드\t결과\t요청ID\tERP상태\t메시지\n' + LIST.map(p => {
    const f = (after.requests || []).find(r => r.request_key === p.request_key);
    return [p.request_key, p.product_code, res[p.request_key][0], f ? f.id : '', f ? f.status : '', res[p.request_key][1]].map(v => String(v).replace(/[\t\n]/g, ' ')).join('\t');
  }).join('\n');
  let h = 0; for (const ch of body) h = (Math.imul(h, 31) + ch.codePointAt(0)) >>> 0;
  return `# ERP 구매 요청 등록 결과 · 받은 시각 ${new Date().toISOString()}\n# 지문 ${h} · 줄 ${body.split('\n').length}\n` + body;
})([]);
