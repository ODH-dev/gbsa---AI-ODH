# -*- coding: utf-8 -*-
"""발주요청서 일꾼 — 검토본 · ERP 등록 예정 내역 · 등록 결과 기록
  python3 도구/ERP등록_준비.py 검토본 [초안.xlsx]
      → 결과/발주요청서검토본_YYMMDD.xlsx (초안 값 옆에 사용자가 확정할 칸. 원본 초안은 그대로)
  python3 도구/ERP등록_준비.py 예정 결과/발주요청서검토본_….xlsx --1차 <계정ID> --최종 <계정ID>
      → 결과/ERP등록예정_YYMMDD.xlsx(보여 줄 내역) + .json(등록 도구에 넣을 내용). ERP에는 아무것도 하지 않음
  python3 도구/ERP등록_준비.py 결과 자료/가져오기원본/ERP_등록결과_….txt
      → 지문 검사 → 결과/ERP등록결과_YYMMDD.xlsx + 결과/ERP등록대장.csv 한 줄씩
"""
import sys, os, glob, json, csv, re, hashlib, datetime as dt
from zoneinfo import ZoneInfo
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter as CL
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(BASE)
NOW = dt.datetime.now(ZoneInfo("Asia/Seoul")); YMD = NOW.strftime("%y%m%d")
CHK = "확인 필요"
thin = Side(style="thin"); BD = Border(left=thin, right=thin, top=thin, bottom=thin)
HF = PatternFill("solid", fgColor="D9D9D9"); IN = PatternFill("solid", fgColor="FFF2CC")
def F(**k): return Font(name="맑은 고딕", **{"size": 10, **k})
def cell(w, r, c, v, bold=False, fill=None, fmt=None, wrap=True):
    x = w.cell(r, c, v); x.font = F(bold=bold); x.border = BD
    x.alignment = Alignment(vertical="center", wrap_text=wrap, horizontal="left" if isinstance(v, str) else "right")
    if fill: x.fill = fill
    if fmt: x.number_format = fmt
    return x
def outname(stem, ext="xlsx"):
    p = f"결과/{stem}_{YMD}.{ext}"; n = 2
    while os.path.exists(p): p = f"결과/{stem}_{YMD}_{n}.{ext}"; n += 1
    return p
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def rows_by_head(ws, hr):
    h = [c.value for c in ws[hr]]
    out = []
    for r in ws.iter_rows(min_row=hr + 1, values_only=True):
        if not r[0] or not isinstance(r[0], (int, float)): break
        out.append(dict(zip(h, r)))
    return out
cmd = sys.argv[1] if len(sys.argv) > 1 else ""
args = sys.argv[2:]
def opt(name):
    return args[args.index(name) + 1] if name in args and args.index(name) + 1 < len(args) else None

if cmd == "검토본":
    src = args[0] if args and not args[0].startswith("--") else sorted(glob.glob("결과/발주요청서초안_*.xlsx"), key=os.path.getmtime)[-1]
    wb0 = openpyxl.load_workbook(src)
    info = {r[0]: r[1] for r in wb0["참고"].iter_rows(values_only=True)}
    items = rows_by_head(wb0["전체검토목록"], 3)
    wb = openpyxl.Workbook(); w = wb.active; w.title = "검토입력"
    H = ["No", "품목코드", "품목명", "단위", "현재 재고", "기준 재고", "권장 발주량", "초안 검토 수량", "초안 거래처", "초안 단가", "참고 단가(과거 거래)",
         "초안 확인 사항", "ERP 기존 요청·초안", "확정 수량", "확정 거래처", "확정 단가", "필요일", "결정(등록/보류)", "금액", "메모"]
    w.cell(1, 1, f"발주요청서 검토본   초안번호 {info.get('초안번호')}   원본 {os.path.basename(src)}   노란 칸만 사용자가 확정한 값으로 채움").font = F(bold=True, size=12)
    for j, h in enumerate(H, 1): cell(w, 3, j, h, True, IN if 14 <= j <= 18 or j == 20 else HF)
    for n, it in enumerate(items, 1):
        r = 3 + n
        v = [n, it["품목코드"], it["품목명"], it["단위"], it["현재 재고"], it["기준 재고"], it["권장 발주량(원본)"], it["발주 검토 수량"],
             it["거래처"], it["단가"], it.get("참고 단가(과거 거래)", "-"), it["확인 사항"], it.get("ERP 기존 요청·초안", "ERP 조회 안 됨"),
             None, None, None, None, None, None, None]
        for j, x in enumerate(v, 1): cell(w, r, j, x, fill=IN if 14 <= j <= 18 or j == 20 else None, fmt="#,##0" if j in (5, 6, 7, 8, 10, 11, 14, 16, 19) else None)
        w.cell(r, 19).value = f'=IF(AND(ISNUMBER(N{r}),ISNUMBER(P{r})),N{r}*P{r},"")'
    for j, x in enumerate([5, 9, 20, 6, 9, 9, 10, 10, 14, 10, 12, 34, 24, 10, 14, 10, 11, 10, 12, 20], 1): w.column_dimensions[CL(j)].width = x
    w.freeze_panes = "D4"
    w2 = wb.create_sheet("초안정보")
    for k, v in [("초안번호", info.get("초안번호")), ("원본 초안", src), ("원본 초안 지문", sha(src)), ("검토본 만든 시각", NOW.strftime("%Y-%m-%d %H:%M")),
                 ("안내", "확정 칸은 사용자가 확인한 값만 넣는다. 결정이 '등록'이고 수량·단가가 숫자인 행만 ERP 등록 예정에 들어간다")]:
        w2.append([k, v])
    w2.column_dimensions["A"].width = 18; w2.column_dimensions["B"].width = 90
    out = outname("발주요청서검토본"); wb.save(out)
    print("검토본 :", out, f"({len(items)}품목, 확정 칸 비어 있음)")

elif cmd == "예정":
    src = args[0]; m1, fin = opt("--1차"), opt("--최종")
    wb0 = openpyxl.load_workbook(src, data_only=False)
    info = {r[0]: r[1] for r in wb0["초안정보"].iter_rows(values_only=True)}
    draft, ver = re.match(r"(DR-\d{6}-[0-9A-F]{6})\s+v(\d+)", str(info["초안번호"])).groups()
    ok_src = os.path.exists(info["원본 초안"]) and sha(info["원본 초안"]) == info["원본 초안 지문"]
    items = rows_by_head(wb0["검토입력"], 3)
    ERPF = (sorted(glob.glob("자료/ERP_발주참고_*.xlsx"), key=os.path.getmtime) or [None])[-1]
    acc, reqs = {}, []
    if ERPF:
        e = openpyxl.load_workbook(ERPF, data_only=True)
        rs = list(e["결재 계정"].iter_rows(values_only=True)); acc = {r[0]: dict(zip(rs[0], r)) for r in rs[1:]}
        rs = list(e["구매 요청"].iter_rows(values_only=True)); reqs = [dict(zip(rs[0], r)) for r in rs[1:]]
    led = list(csv.DictReader(open("결과/ERP등록대장.csv", encoding="utf-8-sig"))) if os.path.exists("결과/ERP등록대장.csv") else []
    done = {r["요청번호"] for r in led if r["상태"] == "등록 완료"}
    prob = []
    if not ok_src: prob.append("검토본의 원본 초안이 없거나 바뀌었습니다")
    if not ERPF: prob.append("ERP 발주 참고 자료가 없습니다(결재자·기존 요청 확인 불가) - 먼저 ERP_발주자료_가져오기")
    if not m1 or not fin: prob.append("결재자(--1차, --최종 계정ID)를 사용자가 지정해야 합니다")
    else:
        a1, a2 = acc.get(m1), acc.get(fin)
        if not a1 or a1["역할"] not in ("admin", "manager") or a1["로그인 연결"] != "예": prob.append("1차 결재자 계정을 확인하세요(로그인한 팀장·관리자)")
        if not a2 or a2["역할"] != "admin" or a2["로그인 연결"] != "예": prob.append("최종 결재자 계정을 확인하세요(로그인한 관리자)")
    OPEN = ("team_pending", "final_pending", "approved")
    go, skip = [], []
    for it in items:
        code, why = it["품목코드"], []
        q, p = it["확정 수량"], it["확정 단가"]
        key = f"{draft}-v{ver}-{code}"
        if str(it["결정(등록/보류)"] or "").strip() != "등록": why.append("등록 결정 없음(보류)")
        if not (isinstance(q, (int, float)) and q == int(q) and q > 0): why.append("확정 수량 확인 필요")
        if not (isinstance(p, (int, float)) and p == int(p) and p > 0): why.append("확정 단가 확인 필요")
        if not it["확정 거래처"]: why.append("확정 거래처 확인 필요")
        if key in done: why.append("이미 등록 완료(같은 요청번호)")
        dup = [r for r in reqs if r.get("종류") == "구매 요청" and str(r.get("품목코드") or "") == code and r.get("상태") in OPEN and r.get("요청번호") != key]
        if dup: why.append("ERP에 같은 품목 진행 중 구매 요청 " + ", ".join(str(r["요청번호"]) for r in dup))
        if why: skip.append((it, " · ".join(why))); continue
        nd = it["필요일"]; nd = nd.strftime("%Y-%m-%d") if hasattr(nd, "strftime") else (str(nd) if nd else CHK)
        desc = (f"발주요청서 초안 {draft} v{ver} · 거래처 {it['확정 거래처']} · 필요일 {nd} · 현재 {it['현재 재고']}{it['단위']} / 기준 {it['기준 재고']}{it['단위']}"
                f" · 권장 발주 {it['권장 발주량']}{it['단위']}(참고치) · 실제 발주·입고는 최종 승인 후 별도 진행")
        go.append(dict(request_key=key, title=f"{it['품목명']} 부족 재고 보충", kind="구매 요청", product_code=code,
                       quantity=int(q), unit_price=int(p), description=desc, manager_id=m1 or "", final_id=fin or "", _name=it["품목명"], _unit=it["단위"], _partner=it["확정 거래처"], _need=nd))
    wb = openpyxl.Workbook(); w = wb.active; w.title = "등록예정"
    w.cell(1, 1, f"ERP 구매 요청 등록 예정 내역   초안 {draft} v{ver}   작성 {NOW:%Y-%m-%d %H:%M}   ※ 아직 등록하지 않음").font = F(bold=True, size=12)
    w.cell(2, 1, f"결재자 : 1차 {m1 or CHK} / 최종 {fin or CHK}   · 등록 단위 : 품목 하나당 구매 요청 1건 → 총 {len(go)}건   · 등록 후 자동 승인하지 않음").font = F()
    H = ["No", "요청번호", "품목코드", "품목명", "거래처", "수량", "단위", "단가", "요청 금액", "필요일", "요청 사유"]
    for j, h in enumerate(H, 1): cell(w, 4, j, h, True, HF)
    for n, g in enumerate(go, 1):
        r = 4 + n
        for j, x in enumerate([n, g["request_key"], g["product_code"], g["_name"], g["_partner"], g["quantity"], g["_unit"], g["unit_price"], None, g["_need"], g["description"]], 1):
            cell(w, r, j, x, fmt="#,##0" if j in (6, 8, 9) else None)
        w.cell(r, 9).value = f"=F{r}*H{r}"
    tr = 5 + len(go)
    cell(w, tr, 1, "등록 예정 합계", True, HF); w.merge_cells(f"A{tr}:H{tr}"); cell(w, tr, 9, f"=SUM(I5:I{tr-1})" if go else 0, True, fmt="#,##0")
    sr = tr + 2; w.cell(sr, 1, f"□ 등록 제외 {len(skip)}건").font = F(bold=True)
    for j, h in enumerate(["No", "품목코드", "품목명", "제외 이유"], 1): cell(w, sr + 1, j, h, True, HF)
    for n, (it, why) in enumerate(skip, 1):
        for j, x in enumerate([n, it["품목코드"], it["품목명"], why], 1): cell(w, sr + 1 + n, j, x)
        w.merge_cells(start_row=sr + 1 + n, start_column=4, end_row=sr + 1 + n, end_column=11)
    for j, x in enumerate([5, 26, 9, 20, 14, 8, 6, 10, 12, 11, 60], 1): w.column_dimensions[CL(j)].width = x
    w.page_setup.paperSize = 9; w.page_setup.orientation = "landscape"; w.page_setup.fitToWidth = 1; w.page_setup.fitToHeight = 0; w.sheet_properties.pageSetUpPr.fitToPage = True
    out = outname("ERP등록예정"); wb.save(out)
    js = out.replace(".xlsx", ".json")
    json.dump({"초안": f"{draft} v{ver}", "검토본": src, "만든시각": NOW.isoformat(), "등록": [{k: v for k, v in g.items() if not k.startswith("_")} for g in go]}, open(js, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("등록 예정 :", out, "/", js)
    print(f"등록 대상 {len(go)}건 · 제외 {len(skip)}건 · 합계 {sum(g['quantity']*g['unit_price'] for g in go):,}원")
    for g in go: print(f"- {g['request_key']} {g['_name']} {g['quantity']:,}{g['_unit']} × {g['unit_price']:,}원 = {g['quantity']*g['unit_price']:,}원 ({g['_partner']}, 필요일 {g['_need']})")
    for it, why in skip: print(f"- 제외 {it['품목코드']} {it['품목명']} : {why}")
    print("등록 가능 :", "아니오" if prob else "예 (사용자가 'ERP에 등록해' 라고 확인한 뒤에만 등록)")
    for p in prob: print("  !", p)

elif cmd == "결과":
    src = args[0]
    text = open(src, encoding="utf-8").read().rstrip("\n"); l1, l2, body = text.split("\n", 2)
    m = re.search(r"지문 (\d+) · 줄 (\d+)", l2); h = 0
    for ch in body: h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    if not m or h != int(m.group(1)) or len(body.split("\n")) != int(m.group(2)): sys.exit("지문이 다릅니다. 저장하지 않았습니다. ERP에서 등록 여부를 다시 조회하세요.")
    rows = [l.split("\t") for l in body.split("\n")[1:] if l]   # 요청번호 품목코드 결과 요청ID ERP상태 메시지
    OPEN = {"team_pending": "1차 결재 대기", "final_pending": "최종 결재 대기", "approved": "승인"}
    wb = openpyxl.Workbook(); w = wb.active; w.title = "등록결과"
    w.cell(1, 1, f"ERP 구매 요청 등록 결과   {l1.lstrip('# ')}").font = F(bold=True, size=12)
    H = ["No", "초안번호", "버전", "품목코드", "요청번호", "ERP 요청ID", "등록 상태", "ERP 결재 상태", "확인 시각", "메모"]
    for j, x in enumerate(H, 1): cell(w, 3, j, x, True, HF)
    new = not os.path.exists("결과/ERP등록대장.csv"); cnt = {}
    with open("결과/ERP등록대장.csv", "a", encoding="utf-8-sig", newline="") as f:
        wr = csv.writer(f)
        if new: wr.writerow(["확인시각", "초안번호", "버전", "품목코드", "요청번호", "ERP요청ID", "상태", "ERP결재상태", "결과파일"])
        out = outname("ERP등록결과")
        for n, r in enumerate(rows, 1):
            key, code, res, rid, st, msg = (r + [""] * 6)[:6]
            mm = re.match(r"(DR-\d{6}-[0-9A-F]{6})-v(\d+)-", key); dr, vv = mm.groups() if mm else ("", "")
            state = "등록 완료" if rid and st in OPEN else ("실패" if res == "실패" else "결과 미확인")
            cnt[state] = cnt.get(state, 0) + 1
            for j, x in enumerate([n, dr, vv, code, key, rid, state, OPEN.get(st, st or "-"), NOW.strftime("%Y-%m-%d %H:%M"), msg], 1): cell(w, 3 + n, j, x)
            wr.writerow([NOW.strftime("%Y-%m-%d %H:%M"), dr, vv, code, key, rid, state, st, out])
    for j, x in enumerate([5, 18, 6, 9, 26, 38, 10, 14, 16, 40], 1): w.column_dimensions[CL(j)].width = x
    wb.save(out)
    print("등록 결과 :", out, " · ", " · ".join(f"{k} {v}건" for k, v in cnt.items()))
    if cnt.get("실패") or cnt.get("결과 미확인"): print("  ! 실패·미확인 건은 새로 등록하지 말고, 같은 요청번호로 등록 여부부터 다시 조회하세요")
else:
    print(__doc__)
