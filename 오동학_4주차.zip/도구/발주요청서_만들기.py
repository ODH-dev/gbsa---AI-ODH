# -*- coding: utf-8 -*-
"""발주요청서 초안 만들기 (발주요청서 일꾼)
사용: python3 도구/발주요청서_만들기.py [부족표.xlsx] [--새버전]
- 부족표를 안 주면 ../재고부족알림_일꾼/결과 의 가장 최근 재고부족표_*.xlsx
- 자료/거래처단가_기준표.xlsx, 자료/미입고발주.xlsx, 자료/필요일.xlsx 가 있으면 함께 사용(없어도 됨)
- 원본은 읽기만 한다. 결과는 결과/발주요청서초안_YYMMDD(_2).xlsx 새 파일
"""
import sys, os, re, glob, hashlib, shutil, subprocess, tempfile, math, csv, datetime as dt
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter as CL

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
args = [a for a in sys.argv[1:] if not a.startswith("--")]
NEWVER = "--새버전" in sys.argv
from zoneinfo import ZoneInfo
KST = ZoneInfo("Asia/Seoul")
NOW = dt.datetime.now(KST)
TODAY = NOW.date()
YMD = TODAY.strftime("%y%m%d")
WEEK = "월화수목금토일"
def kdate(d): return f"{d.year}. {d.month}. {d.day}.({WEEK[d.weekday()]})"
CHK = "확인 필요"

def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

def recalc(path):
    """LibreOffice로 복사본을 다시 계산해 값만 읽는다(원본은 그대로)."""
    tmp = tempfile.mkdtemp()
    src = os.path.join(tmp, "src.xlsx"); shutil.copy(path, src)
    out = os.path.join(tmp, "out"); os.makedirs(out)
    env = dict(os.environ, HOME=tmp)
    subprocess.run(["soffice", "--headless", "--calc", "--convert-to", "xlsx", "--outdir", out, src],
                   check=True, capture_output=True, env=env, timeout=120)
    return openpyxl.load_workbook(os.path.join(out, "src.xlsx"), data_only=True), tmp

# ---------- 1. 부족표 ----------
if args: SRC = args[0]
else:
    c = sorted(glob.glob("../재고부족알림_일꾼/결과/재고부족표_*.xlsx"), key=os.path.getmtime)
    if not c: sys.exit("부족표를 찾지 못했습니다.")
    SRC = c[-1]
FP = sha(SRC)
wbv, TMP = recalc(SRC)
ws = wbv["부족품목표"]
head = [c.value for c in ws[7]]
need = ["제품코드", "제품명", "단위", "기말재고", "기준 재고", "부족수량", "하루 출고", "버틸 날", "권장 발주", "구분"]
NUM = ("기말재고", "기준 재고", "부족수량", "권장 발주")
if [h for h in need if h not in head]: sys.exit(f"부족표 머리글이 다릅니다: {head}")
ix = {h: head.index(h) for h in head if h}
period = str(ws["A5"].value or "").split("작성일")[0].replace("집계 기간 :", "").strip()
items, problems = [], []
for r in ws.iter_rows(min_row=8, values_only=True):
    if not isinstance(r[0], (int, float)): break
    it = {k: r[ix[k]] for k in need}
    it["비고"] = r[ix["비고"]] if "비고" in ix else ""
    for k in NUM:
        if not isinstance(it[k], (int, float)) or it[k] < 0:
            problems.append(f"{it['제품코드']} {k} 값 이상: {it[k]}"); it[k] = None
    items.append(it)
# 원본 품목별집계와 대조
agg = {r[0]: r for r in wbv["품목별집계"].iter_rows(min_row=5, values_only=True) if r[0]}
short_in_agg = sorted(k for k, r in agg.items() if r[12] == "부족")
codes = [i["제품코드"] for i in items]
if len(set(codes)) != len(codes): problems.append("부족표 안에 중복 품목코드가 있습니다")
if sorted(codes) != short_in_agg: problems.append(f"부족품목표({len(codes)})와 품목별집계 부족({len(short_in_agg)}) 불일치")
for i in items:
    a = agg.get(i["제품코드"])
    if not a or a[2] != i["단위"] or a[11] != i["부족수량"]: problems.append(f"{i['제품코드']} 품목별집계와 단위/부족수량 불일치")
shutil.rmtree(TMP, ignore_errors=True)

# ---------- 2. 참고 자료(있을 때만) ----------
def table(path):
    if not os.path.exists(path): return None
    w = openpyxl.load_workbook(path, data_only=True).worksheets[0]
    rows = list(w.iter_rows(values_only=True))
    h = [str(x).strip() if x else "" for x in rows[0]]
    return [dict(zip(h, r)) for r in rows[1:] if any(v not in (None, "") for v in r)]
REF = {"거래처단가": "자료/거래처단가_기준표.xlsx", "미입고": "자료/미입고발주.xlsx", "필요일": "자료/필요일.xlsx"}
ref = {k: table(v) for k, v in REF.items()}
ref_fp = {k: (sha(v)[:8] if os.path.exists(v) else "없음") for k, v in REF.items()}

# ERP 발주 참고 자료(도구/ERP_발주자료_저장.py 가 만든 가장 최근 파일, 있을 때만)
ERPF = (sorted(glob.glob("자료/ERP_발주참고_*.xlsx"), key=os.path.getmtime) or [None])[-1]
erp = None
if ERPF:
    _w = openpyxl.load_workbook(ERPF, data_only=True)
    def _rows(n):
        rs = list(_w[n].iter_rows(values_only=True)); h = list(rs[0])
        return [dict(zip(h, r)) for r in rs[1:]]
    erp = {n: _rows(n) for n in ("품목", "매입 발주", "구매 요청", "자동 초안", "결재 계정")}
    erp["출처"] = {r[0]: r[1] for r in _w["출처"].iter_rows(values_only=True)}
    ref_fp["ERP"] = sha(ERPF)[:8]
else:
    ref_fp["ERP"] = "없음"
OPEN_REQ = {"team_pending": "1차 결재 대기", "final_pending": "최종 결재 대기", "approved": "승인(발주 진행 확인 필요)"}

for it in items:
    code, unit = it["제품코드"], it["단위"]
    notes = []
    # 거래처·단가 : ① 확정 기준표 ② 기준표의 과거 거래 ③ ERP 매입 발주 기록(과거 거래 참고)
    it.update(거래처=None, 거래처상태="거래처 확인 필요", 단가=None, 참고단가=None, 단가출처=CHK, 세금=CHK, 단가기준일=CHK, 최소=None, 포장=None)
    done = False
    if ref["거래처단가"] is not None:
        cand = [r for r in ref["거래처단가"] if str(r.get("품목코드", "")).strip() == code]
        same = [r for r in cand if str(r.get("단위", "")).strip() == unit]
        if cand and not same: notes.append("기준표 단위 다름")
        names = {str(r.get("거래처", "")).strip() for r in same if r.get("거래처")}
        if len(names) == 1:
            r = same[0]; done = True
            kind = str(r.get("구분") or "확정").strip()
            it["거래처"] = names.pop()
            p = r.get("단가") if isinstance(r.get("단가"), (int, float)) and r.get("단가") > 0 else None
            if kind == "확정": it["거래처상태"] = "확정 기준표"; it["단가"] = p
            else: it["거래처상태"] = "과거 거래 참고"; it["참고단가"] = p
            it["단가출처"] = "기준표 " + str(r.get("출처") or "")
            it["세금"] = str(r.get("세금") or CHK)
            it["단가기준일"] = str(r.get("단가기준일") or CHK)
            it["최소"] = r.get("최소주문량") if isinstance(r.get("최소주문량"), (int, float)) else None
            it["포장"] = r.get("포장단위") if isinstance(r.get("포장단위"), (int, float)) else None
        elif len(names) > 1:
            done = True; it["거래처상태"] = f"후보 {len(names)}곳 - 거래처 확인 필요"; notes.append("기준표 후보: " + ", ".join(sorted(names)))
    if not done and erp:
        pu = sorted([r for r in erp["매입 발주"] if str(r.get("품목코드") or "").strip() == code and r.get("매입처")], key=lambda r: str(r.get("발주일") or ""))
        last = {}
        for r in pu: last[str(r["매입처"]).strip()] = r
        if len(last) == 1:
            r = list(last.values())[0]
            it["거래처"] = r["매입처"]; it["거래처상태"] = "과거 거래 참고"
            it["참고단가"] = r["단가"] if isinstance(r.get("단가"), (int, float)) and r["단가"] > 0 else None
            it["단가출처"] = f"ERP 매입 발주 {r['발주번호']}"; it["단가기준일"] = str(r.get("발주일") or CHK)
        elif len(last) > 1:
            it["거래처상태"] = f"과거 거래 후보 {len(last)}곳 - 거래처 확인 필요"
            notes.append("과거 거래 후보: " + ", ".join(f"{k} {v['단가']:,}원({v['발주일']})" if isinstance(v.get('단가'), (int, float)) else k for k, v in last.items()))
        elif not pu:
            it["단가출처"] = "ERP 매입 기록 없음"
    elif not done:
        it["단가출처"] = "기준표 없음"
    if it["거래처상태"] == "과거 거래 참고":
        notes.append("과거 거래 참고 - 현재 거래처·단가 확인" + (f"(참고 단가 {it['참고단가']:,}원, 세금 미상)" if it["참고단가"] and it["세금"] == CHK else ""))
    if not it["거래처"]: notes.append("거래처 확인 필요")
    if it["단가"] is None: notes.append("단가 확인 필요")
    # 수량 (기존 권장량 사용, 확인된 최소주문량·포장단위가 있을 때만 조정)
    rec = it["권장 발주"]; it["검토수량"] = rec; it["조정사유"] = ""
    if rec is None: notes.append("수량 확인 필요")
    elif it["포장"] or it["최소"]:
        q = rec
        if it["포장"]: q = math.ceil(q / it["포장"]) * int(it["포장"])
        if it["최소"]: q = max(q, int(it["최소"]))
        if q != rec:
            it["검토수량"] = q
            it["조정사유"] = f"최소주문량 {it['최소'] or '-'} / 포장단위 {it['포장'] or '-'} 적용"
    # 필요일
    it["필요일"], it["필요일근거"] = CHK, "자료 없음"
    if ref["필요일"]:
        f = [r for r in ref["필요일"] if str(r.get("품목코드", "")).strip() == code and r.get("필요일")]
        if len(f) == 1:
            d = f[0]["필요일"]; it["필요일"] = d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else str(d)
            it["필요일근거"] = str(f[0].get("근거") or "필요일 자료")
    if it["필요일"] == CHK: notes.append("필요일 확인 필요")
    # 미입고 주문 (자동 차감하지 않음) : 미입고발주 자료 → 없으면 ERP 매입 발주 중 '발주완료'(입고 전)
    o, src_ = None, None
    if ref["미입고"] is not None:
        o = [r for r in ref["미입고"] if str(r.get("품목코드", "")).strip() == code]; src_ = "미입고 자료"
        o = [dict(주문번호=r.get("주문번호"), 수량=r.get("수량"), 단위=r.get("단위") or "", 예정일=r.get("예정일"), 상태=r.get("상태") or "상태 미상") for r in o]
    elif erp:
        o = [dict(주문번호=r["발주번호"], 수량=r["발주수량"], 단위=unit, 예정일="예정일 없음(발주일 " + str(r.get("발주일")) + ")", 상태=r.get("상태")) for r in erp["매입 발주"]
             if str(r.get("품목코드") or "").strip() == code and str(r.get("상태") or "") == "발주완료"]; src_ = "ERP 매입 발주"
    if o is None: it["미입고"] = "기존 주문 조회 안 됨"
    elif o:
        it["미입고"] = "; ".join(f"{r['주문번호']} {r['수량']}{r['단위']} {r['예정일']} ({r['상태']})" for r in o)
        notes.append("기존 주문 확인 후 추가 발주 판단")
    else: it["미입고"] = f"{src_}에 미입고 없음"
    # ERP 안에 이미 진행 중인 구매 요청 · 자동 초안 (중복 등록 방지)
    it["ERP기존"] = "ERP 조회 안 됨"
    if erp:
        ex = [f"{r['요청번호']} {r['수량']}{unit} {OPEN_REQ[r['상태']]}" for r in erp["구매 요청"]
              if r.get("종류") == "구매 요청" and str(r.get("품목코드") or "") == code and r.get("상태") in OPEN_REQ]
        ex += [f"ERP 자동 초안 {r['수량']}{unit} ({r['상태']})" for r in erp["자동 초안"]
               if str(r.get("품목코드") or "") == code and r.get("상태") in ("draft", "submitted")]
        it["ERP기존"] = "; ".join(ex) if ex else "없음"
        if ex: notes.append("ERP에 같은 품목 구매 요청·초안 있음 - 중복 확인")
    # 긴급: 기말재고 ÷ 하루 출고 < 2일 (숫자로 계산하고, 부족표 '버틸 날' 표시와 대조)
    d, out = it["기말재고"], it["하루 출고"]
    calc = (d / out) if isinstance(d, (int, float)) and isinstance(out, (int, float)) and out > 0 else None
    m = re.match(r"^([\d.]+)일$", str(it["버틸 날"] or ""))
    shown = float(m.group(1)) if m else None
    it["버틸날수"] = calc
    if calc is None and shown is None: it["긴급"] = ""
    elif calc is not None and shown is not None and (calc < 2) != (shown < 2):
        it["긴급"] = ""; notes.append("긴급 여부 확인 필요(버틸 날 2일 경계)")
    else: it["긴급"] = "긴급" if (calc if calc is not None else shown) < 2 else ""
    it["notes"] = notes

for it in items: it["확인사항"] = " · ".join(dict.fromkeys(it.pop("notes")))

def taxmix(rows):
    t = {str(r["세금"]) for r in rows if r["단가"] is not None and r["검토수량"] is not None}
    return len(t) > 1 or CHK in t

# ---------- 3. 초안번호·버전 / 중복 확인 ----------
LEDGER = "결과/초안대장.csv"
ledger = list(csv.DictReader(open(LEDGER, encoding="utf-8-sig"))) if os.path.exists(LEDGER) else []
key = f"{FP[:12]}|{ref_fp['거래처단가']}|{ref_fp['미입고']}|{ref_fp['필요일']}|{ref_fp['ERP']}"
same = [r for r in ledger if r["자료키"] == key]
if same and not NEWVER:
    print(f"같은 자료로 만든 초안이 이미 있습니다: {same[-1]['파일']} ({same[-1]['초안번호']} v{same[-1]['버전']})")
    print("다시 만들려면 --새버전 을 붙여 실행하세요. (이전 파일은 지우지 않습니다)")
    sys.exit(0)
DRAFT = f"DR-{YMD}-{FP[:6].upper()}"
VER = 1 + max([int(r["버전"]) for r in ledger if r["초안번호"] == DRAFT] or [0])

# ---------- 4. 엑셀 ----------
def outname(stem):
    p = f"결과/{stem}_{YMD}.xlsx"; n = 2
    while os.path.exists(p): p = f"결과/{stem}_{YMD}_{n}.xlsx"; n += 1
    return p
OUT = outname("발주요청서초안")
thin = Side(style="thin", color="000000")
BD = Border(left=thin, right=thin, top=thin, bottom=thin)
HF = PatternFill("solid", fgColor="D9D9D9"); WF = PatternFill("solid", fgColor="FFF2CC")
C = Alignment(horizontal="center", vertical="center", wrap_text=True)
L = Alignment(horizontal="left", vertical="center", wrap_text=True)
R = Alignment(horizontal="right", vertical="center")
def F(**k): return Font(name="맑은 고딕", **{"size": 10, **k})
def put(w, ref_, v, font=None, fill=None, align=C, border=True, fmt=None):
    c = w[ref_]; c.value = v; c.font = font or F(); c.alignment = align
    if fill: c.fill = fill
    if border: c.border = BD
    if fmt: c.number_format = fmt
    return c

wb = openpyxl.Workbook(); wb.remove(wb.active)
groups = {}
def gname(it): return (it["거래처"] + ("(참고)" if it["거래처상태"] == "과거 거래 참고" else "")) if it["거래처"] else "거래처 미확정"
for it in items: groups.setdefault(gname(it), []).append(it)
order = [g for g in groups if g != "거래처 미확정"] + (["거래처 미확정"] if "거래처 미확정" in groups else [])

COLS = ["No", "품목코드", "품목명", "단위", "현재 재고", "기준 재고", "권장 발주량", "발주 검토 수량", "단가", "금액", "필요일", "확인 사항"]
WID = [5, 9, 20, 6, 9, 9, 10, 10, 10, 12, 11, 30]
ROWS_PER_PAGE = 20
sheet_summary = []
for gi, g in enumerate(order, 1):
    w = wb.create_sheet(f"요청서{gi}_{g}"[:31])
    for i, x in enumerate(WID, 1): w.column_dimensions[CL(i)].width = x
    w.merge_cells("A1:H3"); put(w, "A1", "발주요청서 초안", F(size=18, bold=True), border=False)
    for j, t in enumerate(["담당", "팀장", "부서장"]):
        col = CL(10 + j)
        put(w, f"{col}1", t, F(size=9), HF); w.merge_cells(f"{col}2:{col}3"); put(w, f"{col}2", "")
        w[f"{col}3"].border = BD
    put(w, "I1", "결\n재", F(size=9), HF); w.merge_cells("I1:I3")
    info = [("문서번호", "○○ (ERP 등록 후 부여)", "초안번호", f"{DRAFT}-{gi:02d}  v{VER}"),
            ("수    신", "내부 구매담당자", "작 성 일", kdate(TODAY)),
            ("제    목", f"부족 재고 보충 발주요청서 초안 ({g})", "상    태", "발주요청서 초안 (구매 확정 아님)"),
            ("거 래 처", (g.replace("(참고)", " - 과거 거래 참고, 확인 필요") if g != "거래처 미확정" else "거래처 확인 필요"), "근거 자료", f"재고부족표 {os.path.basename(SRC)} ({period})")]
    for k, (a, b, c_, d) in enumerate(info):
        r = 5 + k
        put(w, f"A{r}", a, F(bold=True), HF); w.merge_cells(f"A{r}:B{r}")
        put(w, f"C{r}", b, align=L); w.merge_cells(f"C{r}:G{r}")
        put(w, f"H{r}", c_, F(bold=True), HF); w.merge_cells(f"H{r}:I{r}")
        put(w, f"J{r}", d, align=L); w.merge_cells(f"J{r}:L{r}")
        for col in "BDEFGIKL": w[f"{col}{r}"].border = BD
    put(w, "A10", "□ 요청 내용 : 아래 품목은 기준 재고보다 적어 보충 발주를 검토 요청함", F(bold=True), align=L, border=False); w.merge_cells("A10:L10")
    hr = 11
    for j, h in enumerate(COLS, 1): put(w, f"{CL(j)}{hr}", h, F(bold=True), HF)
    gl = groups[g]
    for n, it in enumerate(gl, 1):
        r = hr + n
        vals = [n, it["제품코드"], it["제품명"], it["단위"], it["기말재고"], it["기준 재고"], it["권장 발주"],
                it["검토수량"] if it["검토수량"] is not None else CHK,
                it["단가"] if it["단가"] is not None else CHK, None, it["필요일"],
                ("[긴급] " if it["긴급"] else "") + it["확인사항"]]
        for j, v in enumerate(vals, 1):
            put(w, f"{CL(j)}{r}", v, align=L if j in (3, 12) else (R if isinstance(v, (int, float)) else C), fmt="#,##0" if j in (5, 6, 7, 8, 9) else None)
        put(w, f"J{r}", f'=IF(AND(ISNUMBER(H{r}),ISNUMBER(I{r})),H{r}*I{r},"")', align=R, fmt="#,##0")
        w.row_dimensions[r].height = max(30, 14 * math.ceil(len(str(vals[11])) / 24) + 4)
        if it["확인사항"]: w[f"L{r}"].fill = WF
    last = hr + len(gl); tr = last + 1
    put(w, f"A{tr}", "확정 입력값 기준 소계", F(bold=True), HF); w.merge_cells(f"A{tr}:I{tr}")
    for col in "BCDEFGHI": w[f"{col}{tr}"].border = BD
    put(w, f"J{tr}", f"=SUM(J{hr+1}:J{last})", F(bold=True), align=R, fmt="#,##0")
    put(w, f"K{tr}", f'="미확정 "&(ROWS(J{hr+1}:J{last})-COUNT(J{hr+1}:J{last}))&"건 제외' + (' · 세금 기준 섞임' if taxmix(gl) else '') + '"', align=C, fill=WF if taxmix(gl) else None); w.merge_cells(f"K{tr}:L{tr}"); w[f"L{tr}"].border = BD
    nr = tr + 2
    for t in ["○ 수량 : 재고부족알림 일꾼의 권장 발주량(부족수량 + 5일치 출고, 참고치)을 그대로 사용함. 임의로 늘리거나 단위를 환산하지 않음",
              "○ 금액 : 수량과 단가가 모두 확인된 행만 계산함. 미확정 행은 소계에서 제외함. 세금(포함/별도) 기준이 다른 단가는 '세금 기준 섞임'으로 표시함",
              "○ 현재 재고 : 부족표의 기말재고(집계 마지막 날 기준)",
              "○ 기존 미입고 주문은 자동 차감하지 않음. 관련 내용은 '전체검토목록'·'참고' 시트 참조",
              "○ 이 문서는 내부 검토용 초안이며, 구매 확정·거래처 발송·입고를 뜻하지 않음"]:
        put(w, f"A{nr}", t, F(size=9), align=L, border=False); w.merge_cells(f"A{nr}:L{nr}"); nr += 1
    ps = w.page_setup; ps.paperSize = 9; ps.orientation = "landscape"; ps.fitToWidth = 1; ps.fitToHeight = 0
    w.sheet_properties.pageSetUpPr.fitToPage = True
    w.print_title_rows = f"{hr}:{hr}"; w.print_options.horizontalCentered = True
    w.page_margins.left = w.page_margins.right = 0.4; w.page_margins.top = w.page_margins.bottom = 0.5
    from openpyxl.worksheet.pagebreak import Break
    for k in range(ROWS_PER_PAGE, len(gl), ROWS_PER_PAGE): w.row_breaks.append(Break(id=hr + k))
    w.print_area = f"A1:L{nr-1}"
    sheet_summary.append((w.title, g, len(gl)))

# 전체 검토 목록
H2 = ["No", "요청서", "품목코드", "품목명", "단위", "현재 재고", "기준 재고", "부족수량", "버틸 날", "긴급", "권장 발주량(원본)",
      "발주 검토 수량", "조정 사유", "거래처", "거래처 상태", "단가", "단가 출처", "단가 기준일", "세금", "금액", "필요일", "필요일 근거",
      "관련 미입고 주문", "확인 사항", "ERP 등록 상태", "참고 단가(과거 거래)", "ERP 기존 요청·초안"]
w = wb.create_sheet("전체검토목록", 0)
put(w, "A1", f"발주요청서 초안 전체 검토 목록   초안번호 {DRAFT} v{VER}   작성일 {kdate(TODAY)}   근거 {os.path.basename(SRC)}", F(bold=True, size=12), align=Alignment(horizontal="left", vertical="center"), border=False); w.merge_cells("A1:AA1")
for j, h in enumerate(H2, 1): put(w, f"{CL(j)}3", h, F(bold=True), HF)
sh_of = {g: f"{t}" for t, g, _ in sheet_summary}
for n, it in enumerate([x for g in order for x in groups[g]], 1):
    r = 3 + n
    vals = [n, sh_of[gname(it)], it["제품코드"], it["제품명"], it["단위"], it["기말재고"], it["기준 재고"], it["부족수량"],
            it["버틸 날"], it["긴급"], it["권장 발주"], it["검토수량"] if it["검토수량"] is not None else CHK, it["조정사유"] or "조정 없음",
            it["거래처"] or CHK, it["거래처상태"], it["단가"] if it["단가"] is not None else CHK, it["단가출처"], it["단가기준일"], it["세금"],
            None, it["필요일"], it["필요일근거"], it["미입고"], it["확인사항"], "미등록", it["참고단가"] if it["참고단가"] else "-", it["ERP기존"]]
    for j, v in enumerate(vals, 1):
        put(w, f"{CL(j)}{r}", v, align=L if j in (4, 13, 15, 17, 23, 24) else C, fmt="#,##0" if j in (6, 7, 8, 11, 12, 16, 26) else None)
    put(w, f"T{r}", f'=IF(AND(ISNUMBER(L{r}),ISNUMBER(P{r})),L{r}*P{r},"")', fmt="#,##0")
last = 3 + len(items)
put(w, f"A{last+1}", "확정 입력값 기준 소계", F(bold=True), HF); w.merge_cells(f"A{last+1}:S{last+1}")
put(w, f"T{last+1}", f"=SUM(T4:T{last})", F(bold=True), fmt="#,##0")
put(w, f"U{last+1}", f'="미확정 "&(ROWS(T4:T{last})-COUNT(T4:T{last}))&"건 제외' + (' · 세금 기준 섞임' if taxmix(items) else '') + '"'); w.merge_cells(f"U{last+1}:V{last+1}")
for j, x in enumerate([5, 16, 9, 18, 6, 9, 9, 9, 9, 6, 11, 11, 14, 14, 16, 9, 12, 11, 8, 11, 11, 10, 20, 30, 10, 12, 24], 1): w.column_dimensions[CL(j)].width = x
w.freeze_panes = "E4"
w.page_setup.paperSize = 9; w.page_setup.orientation = "landscape"; w.page_setup.fitToWidth = 1; w.page_setup.fitToHeight = 0
w.sheet_properties.pageSetUpPr.fitToPage = True

# 참고(자료 출처)
w = wb.create_sheet("참고")
lines = [("초안번호", f"{DRAFT}  v{VER}"), ("작성일", kdate(TODAY)),
         ("부족표", f"{SRC}"), ("부족표 지문(SHA-256)", FP), ("집계 기간", period),
         ("거래처단가 기준표", REF["거래처단가"] + (" (지문 " + ref_fp["거래처단가"] + ")" if ref["거래처단가"] is not None else " - 없음 → 거래처·단가 확인 필요")),
         ("미입고 발주 자료", REF["미입고"] + (" (지문 " + ref_fp["미입고"] + ")" if ref["미입고"] is not None else (" - 없음 → ERP 매입 발주의 '발주완료'(입고 전)로 확인" if erp else " - 없음 → 기존 주문 조회 안 됨(주문이 없다는 뜻 아님)"))),
         ("필요일 자료", REF["필요일"] + (" (지문 " + ref_fp["필요일"] + ")" if ref["필요일"] is not None else " - 없음 → 필요일 확인 필요")),
         ("ERP 발주 참고 자료", (f"{ERPF} (ERP v{erp['출처'].get('ERP 버전')}, 받은 시각 {erp['출처'].get('받은 시각')}, 지문 {ref_fp['ERP']}) - 매입 발주 기록은 과거 거래 참고, 품목코드 없는 구매 요청은 대조 못 함" if erp else "없음 → 과거 거래·ERP 기존 요청 조회 안 됨")),
         ("발주 검토일", kdate(TODAY) + " (부품이 필요한 날과 다름)"),
         ("ERP 등록", "이 파일만으로는 ERP에 등록하지 않음. 사용자 확인 후 별도 단계에서 등록")]
for k, (a, b) in enumerate(lines, 1):
    put(w, f"A{k}", a, F(bold=True), HF); put(w, f"B{k}", b, align=L)
w.column_dimensions["A"].width = 20; w.column_dimensions["B"].width = 100
for rr in range(1, len(lines) + 1): w.row_dimensions[rr].height = max(18, 15 * math.ceil(len(str(lines[rr-1][1])) / 90))
w.page_setup.paperSize = 9; w.page_setup.orientation = "landscape"; w.page_setup.fitToWidth = 1; w.page_setup.fitToHeight = 0; w.sheet_properties.pageSetUpPr.fitToPage = True
wb.save(OUT)

# ---------- 5. 검증 ----------
chk, tmp = recalc(OUT)
errs = [f"{s.title}!{c.coordinate}" for s in chk.worksheets for row in s.iter_rows() for c in row
        if isinstance(c.value, str) and c.value.startswith("#")]
lst = chk["전체검토목록"]
got = [lst.cell(r, 3).value for r in range(4, last + 1)]
recq = {lst.cell(r, 3).value: lst.cell(r, 11).value for r in range(4, last + 1)}
total = lst.cell(last + 1, 20).value
shutil.rmtree(tmp, ignore_errors=True)
if sorted(got) != sorted(codes) or len(set(got)) != len(got): problems.append("초안 품목 누락/중복")
for it in items:
    if recq.get(it["제품코드"]) != it["권장 발주"]: problems.append(f"{it['제품코드']} 권장 발주량 불일치")
if errs: problems.append(f"수식 오류 {len(errs)}개: {errs[:5]}")

new = not os.path.exists(LEDGER)
with open(LEDGER, "a", encoding="utf-8-sig", newline="") as f:
    wr = csv.writer(f)
    if new: wr.writerow(["작성시각", "초안번호", "버전", "파일", "부족표", "자료키", "품목수", "요청서수"])
    wr.writerow([NOW.strftime("%Y-%m-%d %H:%M"), DRAFT, VER, OUT, os.path.basename(SRC), key, len(items), len(order)])

unconf = sum(1 for it in items if it["단가"] is None or it["검토수량"] is None)
print("파일 :", OUT)
print(f"초안번호 : {DRAFT} v{VER}  /  근거 : {SRC} ({period})")
print(f"요청서 {len(order)}장 :", "; ".join(f"{g} {n}품목" for _, g, n in sheet_summary))
print(f"품목 {len(items)}개 (부족표 {len(codes)}개) / 확정 입력값 기준 소계 {total:,}원 / 미확정 {unconf}건 제외")
print("긴급 :", ", ".join(f"{i['제품코드']} {i['제품명']}" for i in items if i["긴급"]) or "없음")
for it in items:
    print(f"- {it['제품코드']} {it['제품명']} : 권장 {it['권장 발주']}{it['단위']} → 검토 {it['검토수량']}{it['단위']} / {it['확인사항'] or '확인 완료'}")
print("검증 :", "이상 없음" if not problems else "문제 있음")
for p in problems: print("  !", p)
